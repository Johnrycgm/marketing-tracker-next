import React from "react";

const variants: Record<string,string> = {
  default: "bg-slate-900 text-white hover:bg-slate-800",
  secondary: "bg-slate-100 hover:bg-slate-200 text-slate-800",
  outline: "border bg-white hover:bg-slate-50",
  ghost: "hover:bg-slate-50",
  destructive: "bg-red-500 text-white hover:bg-red-600"
};
export function Button({
  className = "",
  variant = "default",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof variants }) {
  return <button className={`px-3 py-2 rounded-xl text-sm ${variants[variant]} ${className}`} {...props} />;
}
