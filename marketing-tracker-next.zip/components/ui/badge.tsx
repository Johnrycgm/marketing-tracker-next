import React from "react";
const variants: Record<string,string> = {
  default: "bg-slate-900 text-white",
  secondary: "bg-slate-100 text-slate-800",
  destructive: "bg-red-100 text-red-700 border border-red-200"
};
export function Badge({ className = "", variant = "default", children }: React.PropsWithChildren<{className?: string, variant?: keyof typeof variants}>) {
  return <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs ${variants[variant]} ${className}`}>{children}</span>;
}
